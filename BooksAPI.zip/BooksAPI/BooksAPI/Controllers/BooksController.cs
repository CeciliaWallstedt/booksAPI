﻿using BooksAPI.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Xml.Linq;
using System.IO;

namespace BooksAPI.Controllers
{
    [RoutePrefix("api/books")]
    public class BooksController : ApiController
    {
        // Books stored in list instead of database
        List<Book> dbBooks;

        public BooksController()
        {            
            // Load xml file with book elements
            XDocument xDoc = XDocument.Load(@"C:\Data\BooksAPI\books.xml");            

            // Read xml elements
            var bookElements = from book in xDoc.Descendants("book")
                               select book;

            dbBooks = new List<Book>();

            // Add all xml Book elements to List of Book
            foreach (var book in bookElements)
            {
                Book b = new Book
                {
                    Id = book.Attribute("id").Value,
                    Author = book.Element("author").Value,
                    Title = book.Element("title").Value,
                    Genre = book.Element("genre").Value,
                    Price = Convert.ToDecimal(book.Element("price").Value, new CultureInfo("en-US")),
                    PublishDate = DateTime.Parse(book.Element("publish_date").Value),
                    Description = book.Element("description").Value
                };
                dbBooks.Add(b);
            }
        }

        // GetAllBooks
        [Route("")]
        public IEnumerable<Book> GetBooks()
        {
            return dbBooks;
        }        

        // Search books by title or author
        [Route("search/{searchString}")]
        public IEnumerable<Book> GetBooks(string searchString)
        {
            var books = from b in dbBooks
                        where b.Title.ToUpper().Contains(searchString.ToUpper()) ||
                        b.Author.ToUpper().Contains(searchString.ToUpper())
                        select b;
            return books;
        }

        // Search books by title or author and Category
        [Route("search/{searchString}/{genre}")]
        public IEnumerable<Book> GetBooks(string searchString, string genre)
        {
            var books = from b in dbBooks
                        where ((b.Title.ToUpper().Contains(searchString.ToUpper()) ||
                        b.Author.ToUpper().Contains(searchString.ToUpper())) &&
                        b.Genre == genre)
                        select b;
            return books;
        }

        // Get all Categories
        [Route("genre")]
        public IEnumerable<string> GetAllCategories()
        {
            var books = from b in dbBooks
                        group b by b.Genre into g
                        select g;

            List<string> l = new List<string>();
            foreach (var item in books)
            {
                l.Add(item.Key);
            }
            l.Sort();
            return l;
        }

        // Get all books by Category
        [Route("genre/{genre}")]
        public IEnumerable<Book> GetBooksGenre(string genre)
        {
            var books = from b in dbBooks
                        where b.Genre.ToUpper().Contains(genre.ToUpper())
                        select b;
            return books;
        }

    }
}
